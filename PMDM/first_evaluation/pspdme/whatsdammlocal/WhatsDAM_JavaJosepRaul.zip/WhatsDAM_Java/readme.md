Per carregar el client:

 gradle client:run --args "serverIP usuari"

Per carregar el server 

 gradle server:run
