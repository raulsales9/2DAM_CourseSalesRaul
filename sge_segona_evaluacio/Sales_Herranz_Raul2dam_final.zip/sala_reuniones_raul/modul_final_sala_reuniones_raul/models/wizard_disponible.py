from odoo import models, fields, api

class wizard_disponible(models.TransientModel):
    _name = 'sala_reuniones_raul.wizard_disponible'
    
    sala_id = fields.Many2one("sala_reuniones_raul.sala_reuniones", string="Sala id")
    
    def es_disponible(self):
        self.sala_id.disponible=True
        return {"type": "ir.actions.act_window_close"}