# -*- coding: utf-8 -*-
# from odoo import http


# class SalaReunionesRaul(http.Controller):
#     @http.route('/sala_reuniones_raul/sala_reuniones_raul', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/sala_reuniones_raul/sala_reuniones_raul/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('sala_reuniones_raul.listing', {
#             'root': '/sala_reuniones_raul/sala_reuniones_raul',
#             'objects': http.request.env['sala_reuniones_raul.sala_reuniones_raul'].search([]),
#         })

#     @http.route('/sala_reuniones_raul/sala_reuniones_raul/objects/<model("sala_reuniones_raul.sala_reuniones_raul"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('sala_reuniones_raul.object', {
#             'object': obj
#         })
