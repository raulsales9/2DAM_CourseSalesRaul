from odoo import models, fields, api

class SalaReuniones(models.Model):
    _name = 'sala_reuniones_raul.sala_reuniones'
    _description = 'sala_reuniones.sala_reuniones'
    
    name= fields.Char(string="name",required=True)
    descripcion= fields.Text(string="descripcion")
    reuniones = fields.One2many("sala_reuniones_raul.reuniones","sala",string="Reuniones")
    disponible =fields.Boolean()
