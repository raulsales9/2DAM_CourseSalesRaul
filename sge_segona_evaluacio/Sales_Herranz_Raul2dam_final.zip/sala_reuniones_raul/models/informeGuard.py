from odoo import models, fields

class InformeGuard(models.Model):
    _name = 'sala_reuniones_raul.informe'
    _description = 'Modelo para gestionar informes de reuniones'

    name = fields.Char(string='Nombre', required=True)
    tipo_informe = fields.Selection([('digital', 'Digital'), ('impreso', 'Impreso')], string='Tipo de Informe', required=True)
    descripcion = fields.Text(string='Descripción')
    fecha_creacion = fields.Date(string='Fecha de Creación', default=fields.Date.today())
    imagen_informe = fields.Binary(string='Imagen del Informe')
