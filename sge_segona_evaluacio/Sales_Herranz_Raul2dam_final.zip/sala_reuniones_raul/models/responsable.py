from odoo import models, fields, api

class Responsable(models.Model):
    _inherit = 'res.partner'
    
    metodo = fields.Boolean(string="Es responsable ?")
    reuniones_responsable = fields.Many2many("sala_reuniones_raul.reuniones", string="Reuniones como responsable")
    

    
    
    
    