from odoo import models, fields, api

class Materials(models.Model):
    _name = "sala_reuniones_raul.materials"
    
    nombre = fields.Char(string="Nombre", required=True)
    tiMaterial = fields.Selection([('digital', 'Digital'), ('impreso', 'Impreso'), ('fisico','Fisico')], string='Tipo de Informe', required=True)
    descripcion = fields.Char(string="Descripcion: ")
    reuniones = fields.Many2many("sala_reuniones_raul.reuniones",string="Reuniones: ")
    fAdquisicion = fields.Date(string="Date ", default=fields.Date.today())