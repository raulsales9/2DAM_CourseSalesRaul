from odoo import models, fields, api

class Wizard(models.TransientModel):
    _name = 'sala_reuniones_raul.wizard'
    
    #funcio que pasa el modul actiu
    def _perdefecte(self):
        return self.env['sala_reuniones_raul.reuniones'].browse(self._context.get('active_ids')) 
    
    #crida a la funcio per defecte per a afegir valor per defecte
    reuniones=fields.Many2one('sala_reuniones_raul.reuniones', default=_perdefecte, string="Reunion", required="True")
    partner = fields.Many2many('res.partner', string="Asistentes")
    
    # special=calcel de el xml es una funcio especial que cancela (funcio nativa)
    def launch(self):
        reuniones = self.reuniones
        reuniones.write({"asistentes" : [(6, 0, self.partner.ids)]})
        return {"type": "ir.actions.act_window"}
    
    