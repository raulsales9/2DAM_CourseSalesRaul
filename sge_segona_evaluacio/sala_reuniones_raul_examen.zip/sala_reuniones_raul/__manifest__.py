# -*- coding: utf-8 -*-
{
    'name': "salaReunionesRaul",
    'summary': """
        act1""",
    'description': """
        Testing description
    """,
    'author': "Raul Sales",
    'website': "https://www.yourcompany.com",
    'category': 'Uncategorized',
    'version': '0.1',
    'depends': ['base'],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/sala.xml',
        'data/data.xml',
        'views/reuniones.xml',
        'views/informe.xml',
        'views/responsable.xml',
        'views/materials.xml',
        #'views/informeGuard.xml',
        #'views/busqueda.xml',
        'views/menu.xml',
        'views/wizard.xml'        
    ],
    'demo': [
        'demo/demo.xml',
    ],
}
