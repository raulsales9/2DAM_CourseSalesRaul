from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import timedelta

class Reuniones(models.Model):
    _name = "sala_reuniones_raul.reuniones"
    #valor per defecte
    name = fields.Char(string="name",required=True)
    fechaInicio = fields.Date(string="date",required=True,default=fields.Date.today())
    duracion = fields.Integer(string="duracion", required=True )
    fechaFinal = fields.Datetime(string="End Date", compute="_get_end_date", inverse="_set_end_date")
    asientos = fields.Integer(string="asientos", required=True)
    sala = fields.Many2one("sala_reuniones_raul.sala_reuniones",string="sala", ondelete='cascade')
    responsable = fields.Many2one("res.partner",string="responsable", domain=[("metodo", "=", True)])
    asistentes = fields.Many2many("res.partner", string="asistentes")
    asientosOcupados = fields.Float(string="percentatge", compute="_calc_asientos_ocup", store=True)
    activos = fields.Boolean()
    materials= fields.Many2one("sala_reuniones_raul.materials", string="Materials: ")
    #informe_id = fields.Many2one('sala_reuniones_raul.informeGuard', string='Informe')
    
    @api.depends('asientos','asistentes')
    def _calc_asientos_ocup(self):
        for record in self:
            if record.asientos:
                record.asientosOcupados = (len(record.asistentes) / record.asientos)*100
            else :
                record.asientosOcupados = 0
                
                
    @api.constrains('asientos','asistentes')
    def _validador_asi(self):
        for record in self:
            if record.asientos < 0:
                raise ValidationError("el numero de asientos no puede ser negativo.")
            if len(record.asistentes) > record.asientos:
                raise ValidationError("el numero de asistentes no puede ser mayor  los asientos")
            
    @api.constrains('responsable','asistentes')
    def _validator_responsable(self):
        for record in self:
            if record.responsable and record.responsable in record.asistentes:
                raise ValidationError("no puede ser responsable un asistente")
            
    @api.depends('fechaInicio', 'duracion')
    def _get_end_date(self):
        for record in self:
            if record.fechaInicio and record.duracion:
                start_date = fields.Datetime.from_string(record.fechaInicio)
                record.fechaFinal = start_date + timedelta(hours=record.duracion)

    def _set_end_date(self):
        for record in self:
            if record.fechaInicio and record.fechaFinal:
                start_date = fields.Datetime.from_string(record.fechaInicio)
                end_date = fields.Datetime.from_string(record.fechaFinal)
                duration = (end_date - start_date).seconds / 3600
                record.duracion = duration

    #@api.onchange()
    #   def _calc_asientos(self):
    #       for record in self:
    #           if record.asientos:
    #               record.asientosOcupados = len(record.asistentes) / record.asientos * 100
    #api.depends guarda en bbdd
    