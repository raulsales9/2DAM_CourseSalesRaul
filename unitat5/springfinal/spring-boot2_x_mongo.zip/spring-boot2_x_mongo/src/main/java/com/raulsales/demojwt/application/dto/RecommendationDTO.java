package com.raulsales.demojwt.application.dto;

public class RecommendationDTO {
}
