package com.raulsales.demojwt.domain.entity;

import com.raulsales.demojwt.application.dto.RecommendationDTO;

import java.util.List;

public class Recommendation {
    private String observaciones;
}
