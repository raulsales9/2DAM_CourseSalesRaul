package com.raulsales.demojwt.domain.entity;

public enum Role {
    ADMIN,
    USER  
}
