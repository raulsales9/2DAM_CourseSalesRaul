package com.raulsales.demojwt.domain.entity;

public class Location {
    private String type;
    private double[] coordinates;
}
