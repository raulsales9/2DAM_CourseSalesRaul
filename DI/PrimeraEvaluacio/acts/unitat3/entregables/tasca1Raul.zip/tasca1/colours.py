light_theme = {
    "background": "#FFFFFF",
    "text": "#000000",
    # Añade más colores según sea necesario
}

dark_theme = {
    "background": "#000000",
    "text": "#FFFFFF",
    # Añade más colores según sea necesario
}